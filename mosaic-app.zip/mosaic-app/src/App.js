import React, { useCallback, useMemo, useState, useEffect } from 'react';
import axios from "axios";
import Student from './component/Student';
import "./App.css"

// move to a config or env file
const API_URL = "https://api.hatchways.io/assessment/students";

// TODO: Here are some of the things I would improve on if I had more time
// I would add focus status to inputs
// I would manage students data in a central store (maybe using context API) or normalized key-value object to make retrieval and updates faster
// I would the app responsive and improve accessiblity
// I would break tags and search inouts into their own components
// Add error handling
// I would persist the data locally in storage

function App() {
  const [loading, setLoading] = useState(true)
  const [students, setStudents] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [searchTag, setSearchTag] = useState("");

  useEffect(() => {
    const getStudents = async () => {
      try {
        const { data } = await axios.get(API_URL)
        setStudents(data.students);
      } catch (error) {
        console.log(error.response)
      } finally {
        setLoading(false)
      }
    }
    getStudents()
  }, []);

  // memoize callback, we could do without this since it's simple but adding it for consistency
  const handleSearchTerm = useCallback((event) => {
    setSearchTerm(event.target.value)
  }, [])
  const handleSearchTag = useCallback((event) => {
    setSearchTag(event.target.value)
  }, [])

  // memoize filters as this does a lot
  // TODO; Would move this out to a utility function for search
  const filteredStudents = useMemo(() => students.filter(student => {
    // if no search term, show all students
    if (!searchTerm && !searchTag) return true

    // split to support full name search
    const searchTermMatch = searchTerm.split(' ').some(term => {
      const searchTermRegex = new RegExp(term, 'i');
      const firstNameMatch = student.firstName.search(searchTermRegex) > -1
      const lastNameMatch = student.lastName.search(searchTermRegex) > -1
      return firstNameMatch || lastNameMatch
    })

    // split to support tags with spaces
    const searchTagMatch = searchTag.split(' ').some(term => {
      const searchTagRegex = new RegExp(term, 'i');
      return (student.tags || []).some(tag => tag.search(searchTagRegex) > -1)
    })

    return searchTermMatch && searchTagMatch;
  }), [searchTerm, searchTag, students])


  const handleOnAddTag = useCallback((tag, student) => {
    // add tags to current student
    // would have been easier if we stored the students as normalized key value
    setStudents(prevStudents => prevStudents.map(stu => {
      if (stu.id === student.id) {
        return {
          ...student,
          tags: [...student.tags || [], tag]
        }
      }
      return stu
    }))
  }, [])

  if (loading) {
    return (
      <div className="loading">
        Loading
      </div>
    )
  }

  return (
    <div className="wrapper">
      <div className="container">
        <div className="search-bar-container">
          <input className="search-bar" value={searchTerm} onChange={handleSearchTerm} placeholder="Search by name" />
        </div>
        <div className="search-bar-container">
          <input className="search-bar" value={searchTag} onChange={handleSearchTag} placeholder="Search by tag" />
        </div>
        {filteredStudents.map(student => (<Student key={student.id} student={student} onAddTag={handleOnAddTag} />))}
        {!filteredStudents.length && (
          <div className="not-found">
            No students found
         </div>
        )}
      </div>
    </div>

  );
}

export default App;