import React, { useState, useCallback } from 'react';

// TODO: I would make grades a proper table in a production app
const Student = ({ student, onAddTag }) => {
    const [showGrades, setShowGrades] = useState(false)
    const [tagInput, setTagInput] = useState("")
    const sumOfGrages = student.grades.reduce((acc, curr) => acc + Number(curr), 0)
    const numberOfGrades = student.grades.length
    const average = sumOfGrages / numberOfGrades

    const handleGradeToggle = useCallback(() => {
        setShowGrades(prev => !prev)
    }, [])

    const handleTagOnChange = useCallback((event) => {
        setTagInput(event.target.value)
    }, [])

    const handleOnSubmit = useCallback((event) => {
        event.preventDefault()
        setTagInput("")
        onAddTag(tagInput, student)
    }, [onAddTag, tagInput, student])

    return (
        <div className="student-container">
            <div className="student-image">
                <img src={student.pic} />
            </div>
            <div className="student-details">
                <div>
                    <h1>{student.firstName} {student.lastName}</h1>
                    <button onClick={handleGradeToggle}>{showGrades ? "➖" : "➕"}</button>
                </div>
                <div className="student-details-body">
                    <p>Email: {student.email}</p>
                    <p>Company: {student.company}</p>
                    <p>Skill: {student.skill}</p>
                    <p>Average: {average}%</p>

                    {showGrades && (
                        <div className="grades">
                            {student.grades.map((grade, index) => (
                                <div key={grade}>
                                    <span>Test {index + 1}: &nbsp;&nbsp;&nbsp;&nbsp;{grade}%</span>
                                </div>
                            ))}
                        </div>
                    )}

                    <div className="tags-container">
                        {(student.tags || []).map(tag => <span key={tag} className="tag">{tag}</span>)}
                    </div>

                    <form onSubmit={handleOnSubmit}>
                        <input className="tag-input" value={tagInput} onChange={handleTagOnChange} placeholder="Add tag" />
                    </form>
                </div>
            </div>
        </div>
    );
}

export default Student;